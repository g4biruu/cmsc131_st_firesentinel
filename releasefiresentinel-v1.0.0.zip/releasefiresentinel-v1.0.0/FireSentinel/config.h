#ifndef CONFIG_H
#define CONFIG_H

// Pin configuration
#define SERVO1_PIN        10
#define SERVO2_PIN        9
#define FLAME_ANALOG_PIN  A0
#define RELAY_PIN         7
#define GSM_RX_PIN        2
#define GSM_TX_PIN        3

// Phone number for SMS alerts
#define PHONE_NUMBER "+639277133957"  // adjust as needed

// Flame sensor configuration
const int FLAME_THRESHOLD = 850;  // adjust by experiment
const int READINGS_COUNT  = 5;    // number of samples to average

#endif
