FireSentinel v1.0.0
===================

Contents:
- FireSentinel.ino  : Main Arduino sketch
- config.h          : Pin and threshold configuration
- README.txt        : This file

Requirements:
- Arduino Uno R3
- 2x SG90 servos
- IR flame sensor (analog)
- Relay + 12V pump + GSM module (optional for SMS)
- Libraries: Servo.h, SoftwareSerial.h

Build:
1. Open FireSentinel.ino in Arduino IDE.
2. Adjust PHONE_NUMBER and FLAME_THRESHOLD in config.h.
3. Select "Arduino Uno" board and correct COM port.
4. Upload to Arduino.

Wiring:
- See project report / wiring diagram section.
- All grounds must be common.
- Separate power for pump, servos, and Arduino.
